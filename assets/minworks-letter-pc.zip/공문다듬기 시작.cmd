@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -X utf8 formal_draft.py
goto done
:python
python -X utf8 formal_draft.py
:done
if errorlevel 1 pause
